"""
Samer Trader Backend - Phase 1

This module defines the FastAPI application for the Samer Trader backend.
It exposes endpoints for user authentication (JWT based), strategy management,
backtesting using Backtrader and performance analytics.  This is a skeleton
implementation to kick off Phase 1 of the roadmap.  As development progresses
additional routes and business logic will be added.

Note: external packages such as FastAPI, Pydantic, python‑jose, passlib and
backtrader must be installed in the codespace environment.  You can install
these with pip:

    pip install fastapi uvicorn[standard] python-jose[cryptography] passlib[bcrypt] backtrader pandas

The app can be run locally via:

    uvicorn backend.main:app --reload

This will start a development server on http://127.0.0.1:8000
"""

from datetime import datetime, timedelta
from typing import List, Optional

from fastapi import Depends, FastAPI, HTTPException, status
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from jose import JWTError, jwt
from passlib.context import CryptContext
from pydantic import BaseModel

from . import models, backtesting, storage

app = FastAPI(title="Samer Trader Backend", version="0.1.0")

# Secret key and algorithm for JWT – in a production environment these should
# be stored securely (e.g. environment variables or a secrets manager).
SECRET_KEY = "CHANGE_ME_TO_A_RANDOM_SECRET_KEY"
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 60 * 24  # 1 day

# Password hashing context
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

# OAuth2 scheme for token retrieval
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="token")


class Token(BaseModel):
    """Response model for access tokens."""
    access_token: str
    token_type: str


class TokenData(BaseModel):
    username: Optional[str] = None


def verify_password(plain_password: str, hashed_password: str) -> bool:
    """Verify a plaintext password against a hashed password."""
    return pwd_context.verify(plain_password, hashed_password)


def get_password_hash(password: str) -> str:
    """Hash a plaintext password."""
    return pwd_context.hash(password)


def authenticate_user(username: str, password: str) -> Optional[models.UserInDB]:
    """Retrieve a user from storage and verify their password."""
    user = storage.get_user(username)
    if not user:
        return None
    if not verify_password(password, user.hashed_password):
        return None
    return user


def create_access_token(data: dict, expires_delta: Optional[timedelta] = None) -> str:
    """Create a JWT access token for the given data."""
    to_encode = data.copy()
    expire = datetime.utcnow() + (expires_delta or timedelta(minutes=15))
    to_encode.update({"exp": expire})
    encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
    return encoded_jwt


async def get_current_user(token: str = Depends(oauth2_scheme)) -> models.UserInDB:
    """Dependency that returns the current authenticated user from the token."""
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        username: str = payload.get("sub")
        if username is None:
            raise credentials_exception
        token_data = TokenData(username=username)
    except JWTError:
        raise credentials_exception
    user = storage.get_user(token_data.username)
    if user is None:
        raise credentials_exception
    return user


@app.post("/register", status_code=status.HTTP_201_CREATED)
def register_user(user: models.UserCreate) -> models.User:
    """Register a new user with username/password."""
    existing = storage.get_user(user.username)
    if existing:
        raise HTTPException(status_code=400, detail="Username already registered")
    hashed = get_password_hash(user.password)
    new_user = models.UserInDB(
        username=user.username,
        hashed_password=hashed,
        full_name=user.full_name,
        email=user.email,
    )
    storage.save_user(new_user)
    return models.User(**new_user.dict(exclude={"hashed_password"}))


@app.post("/token", response_model=Token)
async def login_for_access_token(form_data: OAuth2PasswordRequestForm = Depends()):
    """OAuth2 compatible token login, returns JWT access token."""
    user = authenticate_user(form_data.username, form_data.password)
    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect username or password",
            headers={"WWW-Authenticate": "Bearer"},
        )
    access_token_expires = timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    access_token = create_access_token(
        data={"sub": user.username}, expires_delta=access_token_expires
    )
    return Token(access_token=access_token, token_type="bearer")


@app.get("/users/me", response_model=models.User)
async def read_users_me(current_user: models.UserInDB = Depends(get_current_user)):
    """Return the current authenticated user's public details."""
    return models.User(**current_user.dict(exclude={"hashed_password"}))


@app.post("/strategies", response_model=models.Strategy)
def create_strategy(strategy: models.StrategyCreate, current_user: models.UserInDB = Depends(get_current_user)):
    """Persist a new trading strategy for the current user."""
    saved = storage.save_strategy(current_user.username, strategy)
    return saved


@app.get("/strategies", response_model=List[models.Strategy])
def list_strategies(current_user: models.UserInDB = Depends(get_current_user)):
    """List all strategies for the current user."""
    return storage.list_strategies(current_user.username)


@app.post("/backtest", response_model=models.BacktestResult)
def run_backtest(req: models.BacktestRequest, current_user: models.UserInDB = Depends(get_current_user)):
    """Run a backtest for a given strategy on historical data and return results."""
    # Retrieve the strategy definition from storage
    strategy = storage.get_strategy(current_user.username, req.strategy_id)
    if not strategy:
        raise HTTPException(status_code=404, detail="Strategy not found")
    try:
        result = backtesting.run_backtest(
            strategy_definition=strategy.definition,
            start_date=req.start_date,
            end_date=req.end_date,
            initial_cash=req.initial_cash,
            commission=req.commission,
            slippage=req.slippage,
            tax_profile=req.tax_profile,
            data_source=req.data_source,
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    return result


@app.get("/data/symbols", response_model=List[str])
def list_available_symbols():
    """Return a list of available symbols from the data store."""
    return storage.list_symbols()


@app.post("/data/upload")
def upload_data(dataset: models.HistoricalDataUpload, current_user: models.UserInDB = Depends(get_current_user)):
    """Upload a CSV dataset to be used for backtesting or paper trading."""
    try:
        storage.save_dataset(dataset.symbol, dataset.csv_data)
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))
    return {"detail": "Dataset uploaded"}


@app.get("/health")
def health() -> dict:
    """Simple health endpoint."""
    return {"status": "ok"}