"""
Backtesting utilities for Samer Trader.

This module wraps the Backtrader framework to execute historical backtests
based on strategy definitions.  For Phase 1 we implement a simple runner
that accepts a strategy definition expressed as a dictionary of indicators
and rules.  In production this would be translated into a custom Backtrader
strategy class on the fly.
"""

from datetime import date
from typing import Dict, Any, List

try:
    import backtrader as bt
    import pandas as pd
except ImportError:
    # If dependencies are missing, we define dummy placeholders so the module
    # can be imported without executing backtests.  The codespace should
    # install backtrader and pandas for full functionality.
    bt = None  # type: ignore
    pd = None  # type: ignore

from .models import BacktestResult, BacktestMetrics, TradeResult
from . import storage


def _load_data(symbol: str) -> Any:
    """Load a CSV dataset into a pandas DataFrame."""
    if pd is None:
        raise RuntimeError("pandas is not installed")
    csv_text = storage.load_dataset(symbol)
    from io import StringIO

    df = pd.read_csv(StringIO(csv_text), parse_dates=True, index_col=0)
    return df


def run_backtest(
    strategy_definition: Dict[str, Any],
    start_date: date,
    end_date: date,
    initial_cash: float,
    commission: float,
    slippage: float,
    tax_profile: str,
    data_source: str,
) -> BacktestResult:
    """
    Execute a backtest using Backtrader.

    Parameters:
        strategy_definition: dict containing the indicators and rules
        start_date: start of the backtest period
        end_date: end of the backtest period
        initial_cash: starting capital
        commission: commission per trade
        slippage: slippage per trade
        tax_profile: tax profile identifier (e.g. 'US_FED_CT')
        data_source: symbol corresponding to uploaded dataset

    Returns:
        BacktestResult with equity curve, trade list and performance metrics.
    """
    if bt is None or pd is None:
        raise RuntimeError(
            "backtrader and pandas must be installed in the codespace to run backtests"
        )

    # Load data
    df = _load_data(data_source)
    # Filter by date range
    df = df.loc[str(start_date) : str(end_date)]

    class GenericStrategy(bt.Strategy):
        params = dict()

        def __init__(self):
            self.data_close = self.datas[0].close
            # TODO: dynamically add indicators based on strategy_definition
            # For Phase 1 we simply track close price to generate buy/sell signals
            self.order = None

        def next(self):
            # Very naive strategy: buy when no position, sell on crossover logic
            if not self.position:
                # Example: always buy on first bar
                self.order = self.buy()
            else:
                # Example: sell after holding for 10 bars
                if len(self) >= 10:
                    self.order = self.sell()

    # Create Cerebro engine
    cerebro = bt.Cerebro()
    cerebro.addstrategy(GenericStrategy)
    cerebro.broker.set_cash(initial_cash)
    cerebro.broker.setcommission(commission=commission)
    if slippage:
        cerebro.broker.set_slippage_perc(slippage)

    data = bt.feeds.PandasData(dataname=df)
    cerebro.adddata(data)
    # Run backtest
    cerebro.run()
    # Collect results
    # Equity curve extracted from broker value each step
    equity_curve = [initial_cash]
    for value in cerebro.broker.datas[0].close.array:
        # This is a placeholder; proper equity curve should include positions
        equity_curve.append(value)

    # Trades: not implemented (Backtrader records trades in broker positions).
    trades: List[TradeResult] = []
    # Compute metrics – placeholder values
    metrics = BacktestMetrics(
        net_profit=equity_curve[-1] - equity_curve[0],
        max_drawdown=0.0,
        sharpe_ratio=0.0,
        profit_factor=1.0,
        win_rate=0.0,
        win_ratio=0.0,
    )
    return BacktestResult(equity_curve=equity_curve, trades=trades, metrics=metrics)