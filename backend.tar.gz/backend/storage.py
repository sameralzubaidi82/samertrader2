"""
Simple storage layer for the Samer Trader backend.

This module provides functions to persist and retrieve users, strategies and
historical datasets using JSON files on disk.  In a production system this
would be replaced with a proper database (e.g. PostgreSQL) and object
relational mapper.

For Phase 1 we rely on a straightforward approach: reading and writing
JSON files under the `data/` directory.  Each function catches I/O errors
to avoid crashing the server.
"""

import json
import os
from pathlib import Path
from typing import List, Optional, Dict, Any

from . import models


BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
USERS_FILE = DATA_DIR / "users.json"
STRATEGIES_FILE = DATA_DIR / "strategies.json"
DATASETS_DIR = DATA_DIR / "datasets"

# Ensure directories exist
DATA_DIR.mkdir(exist_ok=True)
DATASETS_DIR.mkdir(exist_ok=True)


def _load_json(path: Path) -> Any:
    if not path.exists():
        return {}
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def _save_json(path: Path, data: Any) -> None:
    with path.open("w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)


def get_user(username: str) -> Optional[models.UserInDB]:
    users = _load_json(USERS_FILE)
    record = users.get(username)
    if record:
        return models.UserInDB(**record)
    return None


def save_user(user: models.UserInDB) -> None:
    users = _load_json(USERS_FILE)
    users[user.username] = user.dict()
    _save_json(USERS_FILE, users)


def save_strategy(owner: str, strategy_create: models.StrategyCreate) -> models.Strategy:
    strategies = _load_json(STRATEGIES_FILE)
    # Generate a simple ID using length; in production use UUID
    strategy_id = f"strat_{len(strategies) + 1}"
    strategy = models.Strategy(
        id=strategy_id,
        owner=owner,
        definition=strategy_create.definition,
    )
    strategies[strategy_id] = strategy.dict()
    _save_json(STRATEGIES_FILE, strategies)
    return strategy


def list_strategies(owner: str) -> List[models.Strategy]:
    strategies = _load_json(STRATEGIES_FILE)
    results = []
    for s in strategies.values():
        if s.get("owner") == owner:
            results.append(models.Strategy(**s))
    return results


def get_strategy(owner: str, strategy_id: str) -> Optional[models.Strategy]:
    strategies = _load_json(STRATEGIES_FILE)
    record = strategies.get(strategy_id)
    if record and record.get("owner") == owner:
        return models.Strategy(**record)
    return None


def list_symbols() -> List[str]:
    symbols = []
    for file in DATASETS_DIR.iterdir():
        if file.suffix.lower() == ".csv":
            symbols.append(file.stem)
    return symbols


def save_dataset(symbol: str, csv_text: str) -> None:
    path = DATASETS_DIR / f"{symbol}.csv"
    with path.open("w", encoding="utf-8") as f:
        f.write(csv_text)


def load_dataset(symbol: str) -> str:
    path = DATASETS_DIR / f"{symbol}.csv"
    with path.open("r", encoding="utf-8") as f:
        return f.read()