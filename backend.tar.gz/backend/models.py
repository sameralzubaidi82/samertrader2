"""
Pydantic models for Samer Trader backend.

These data classes describe the payloads for API requests and responses.
They do not include persistence logic; see storage.py for CRUD operations.
"""

from datetime import date
from typing import List, Optional, Dict, Any

from pydantic import BaseModel, Field, EmailStr


class UserBase(BaseModel):
    username: str
    full_name: Optional[str] = None
    email: Optional[EmailStr] = None


class UserCreate(UserBase):
    password: str


class User(UserBase):
    id: Optional[int] = None

    class Config:
        orm_mode = True


class UserInDB(UserBase):
    hashed_password: str

    class Config:
        orm_mode = True


class IndicatorConfig(BaseModel):
    """Configuration for a single indicator used in a strategy."""
    name: str
    params: Dict[str, Any] = Field(default_factory=dict)


class StrategyDefinition(BaseModel):
    """High‑level description of a trading strategy.

    The `indicators` field defines which technical indicators are used and with
    what parameters.  The `rules` field contains conditional logic expressed
    as a simple expression tree or domain specific language.  Implementation
    details for parsing and executing the rules are handled in the backend.
    """
    name: str
    description: Optional[str] = None
    indicators: List[IndicatorConfig] = Field(default_factory=list)
    rules: Dict[str, Any] = Field(default_factory=dict)


class Strategy(BaseModel):
    id: str
    owner: str
    definition: StrategyDefinition

    class Config:
        orm_mode = True


class StrategyCreate(BaseModel):
    definition: StrategyDefinition


class BacktestRequest(BaseModel):
    strategy_id: str
    start_date: date
    end_date: date
    initial_cash: float = 10000.0
    commission: float = 0.0
    slippage: float = 0.0
    tax_profile: Optional[str] = None  # e.g. 'US_FED_CT'
    data_source: Optional[str] = None  # symbol or dataset key


class TradeResult(BaseModel):
    """Details of an individual trade executed during a backtest."""
    time: str
    symbol: str
    side: str
    quantity: int
    price: float
    pnl: float


class BacktestMetrics(BaseModel):
    net_profit: float
    max_drawdown: float
    sharpe_ratio: float
    profit_factor: float
    win_rate: float
    win_ratio: float


class BacktestResult(BaseModel):
    """Response model for backtest results."""
    equity_curve: List[float]
    trades: List[TradeResult]
    metrics: BacktestMetrics


class HistoricalDataUpload(BaseModel):
    symbol: str
    csv_data: str  # CSV encoded as text